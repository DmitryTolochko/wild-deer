public enum Age 
{
    Newborn,
    Child,
    Adult,
    Elder,
    Dead
}
