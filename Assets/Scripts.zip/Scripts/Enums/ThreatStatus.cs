public enum ThreatStatus
{
    Spawned,
    Defeated,
    Won
}
