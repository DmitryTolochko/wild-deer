public enum ThreatType 
{
    CuttingPoacher,
    KillerPoacher,
    Wolf,
    Wolverine,
    ArcticFox,
    Temperature,
    Parasite,
    Insects,
    Lemming,
    DirtyWater,
    Garbage
}
