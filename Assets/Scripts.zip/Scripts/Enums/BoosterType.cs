﻿namespace ServiceInstances
{
    public enum BoosterType
    {
        PinkTrap,
        // MeshTree,
        // HiddenPit,
        // SmellDecoy,
        // DeerRobot,
        // SnowFence,
        ProtectiveCap,
        // Medicines,
        // HugeFan,
        // WaterFilter,
        Food,
        // Inhabitant
    }

}