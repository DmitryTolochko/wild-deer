public enum Gender
{
    Female,
    Male
}
