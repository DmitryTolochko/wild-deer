using System;
using Model.Inventory;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;
using System.Net.Sockets;


public class InventoryUI : MonoBehaviour
{
    /*private Inventory inventory;*/
    private Transform itemSlotContainer;
    private Transform itemSlotTemplate;
    private Transform itemAmount;
    public static InventoryUI Instance { get; private set; }


    private void Awake()
    {
        Instance = this;
        itemSlotContainer = transform.Find("itemSlotContainer");
        itemSlotTemplate = itemSlotContainer.Find("itemSlotTemplate");
        itemAmount = itemSlotTemplate.Find("itemAmount");
    }

    /*
    public void SetInventory(Inventory inventory)
    {
        this.inventory = inventory;
        inventory.ItemAdded += RefreshInventoryItems;
        inventory.BoosterUsed += RefreshInventoryItems;
        RefreshInventoryItems();
    }
    */

    private void Start()
    {
        Inventory.ItemAdded += RefreshInventoryItems;
        Inventory.BoosterUsed += RefreshInventoryItems;
        RefreshInventoryItems();
    }

    public void RefreshInventoryItems()
    {
        foreach (var child in itemSlotContainer)
        {
            var temp = child as Transform;
            if (temp != itemSlotTemplate)
            {
                Destroy(temp.gameObject);
            }
        }

        var x = 0;
        var offset = 141.5f;
        var boosterPrefab = BoostersAssets.Instance.boosterPrefab;
        foreach (var item in Inventory.GetAllItems())
        {
            var itemType = item.Type;

            var instance = Instantiate(boosterPrefab, itemSlotContainer);
            instance.GetComponent<BoosterWorld>().SetBoosterType(itemType);

            var itemSlotRectTransform = instance.GetComponent<RectTransform>();
            itemSlotRectTransform.gameObject.SetActive(true);
            itemSlotRectTransform.anchoredPosition = new Vector2(x * offset, 0);

            var image = itemSlotRectTransform.Find("image").GetComponent<Image>();
            image.sprite = BoostersAssets.GetSprite(itemType);

            var text = itemSlotRectTransform.Find("itemAmount").GetComponent<TextMeshProUGUI>();
            text.SetText(item.Amount > 1 ? $"x{item.Amount.ToString()}" : string.Empty);
            x++;
        }
    }
}