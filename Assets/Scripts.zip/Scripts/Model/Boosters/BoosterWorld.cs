using System;
using System.Linq;
using Model.Boosters;
using Model.Inventory;
using ServiceInstances;
using UnityEngine;

public class BoosterWorld : MonoBehaviour
{
    private bool isPlaced;
    private Collider2D gameFieldBounds;
    private BoxCollider2D boosterCollider;
    private Vector3 startPosition;
    private Vector3 mousePositionOffset;
    public Inventory inventory;

    private Vector3 GetMouseWorldPosition() => Camera.main.ScreenToWorldPoint(Input.mousePosition);

    public BoosterType Type { get; private set; }
    public static event Action<BoosterType> BoosterPlaced;
    public static event Action BoosterTaken;


    private void Start()
    {
        startPosition = transform.position;

        var gameField = Resources
            .FindObjectsOfTypeAll<GameObject>()
            .FirstOrDefault(x => x.name == "GameField")!;
        gameFieldBounds = gameField.GetComponent<PolygonCollider2D>();
        BoosterPlaced += booster => transform.SetParent(gameField.transform);
    }

    public void SetBoosterType(BoosterType type)
    {
        Type = type;
    }

    private void OnMouseDown()
    {
        BoosterTaken?.Invoke();
        mousePositionOffset = gameObject.transform.position - GetMouseWorldPosition();
    }

    private void OnMouseDrag()
    {
        if (!isPlaced)
            transform.position = GetMouseWorldPosition() + mousePositionOffset;
    }

    private void OnMouseUp()
    {
        var kek = boosterCollider = GetComponent<BoxCollider2D>();
        if (gameFieldBounds.Distance(kek).distance < -0.5)
        {
            isPlaced = true;
            BoosterPlaced?.Invoke(Type);
            inventory.AddItem(GetProperBooster());
            return;
        }

        transform.position = startPosition;
    }


    private IBooster GetProperBooster()
    {
        return Type switch
        {
            BoosterType.Food => new FoodBooster(),
            BoosterType.PinkTrap => new PinkTrapBooster(),
            BoosterType.ProtectiveCap => new ProtectiveCapBooster()
        };
    }
}