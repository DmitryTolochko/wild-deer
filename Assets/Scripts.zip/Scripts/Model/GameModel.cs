using Model.Boosters;
using Model.Food;
using Model.Inventory;
using ServiceInstances;
using UnityEngine;
using UnityEngine.Serialization;

public class GameModel : MonoBehaviour
{
    [FormerlySerializedAs("uiInventory")] [SerializeField] private InventoryUI inventoryUI;
    /*private Inventory inventory;*/


    private void Awake()
    {
        /*inventory = new Inventory();*/
        /*inventoryUI.SetInventory(inventory);*/

        /*FoodWorld.FoodCollected += () =>
        {
            inventory.AddItem(new FoodBooster());
        };*/
    }
}